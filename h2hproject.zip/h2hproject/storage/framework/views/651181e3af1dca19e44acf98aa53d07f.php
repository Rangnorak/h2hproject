<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <h5 class="card-header"><?php echo e(__('Data User')); ?></h5>
                <div class="card-body">
                    <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary btn-sm">Tambah Data</a>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama</th>
                                    <th>No.HP</th>
                                    <th>Email</th>
                                    <th>Akses</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->name); ?></td>
                                        <td><?php echo e($item->nohp); ?></td>
                                        <td><?php echo e($item->email); ?></td>
                                        <td><?php echo e($item->akses); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('user.edit', $item->id)); ?>">
                                                Edit
                                            </a>
                                            |
                                            <a href="<?php echo e(route('user.destroy', $item->id)); ?>" href="#" onclick="event.preventDefault(); document.getElementById('user-<?php echo e($item->id); ?>').submit();">
                                                <form id="user-<?php echo e($item->id); ?>" action="<?php echo e(route('user.destroy', $item->id)); ?>" style="hidden" method="POST" class="d-none">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                </form>
                                                Hapus
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4">Data Tidak Ada</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <?php echo $users->links(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_sneat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\h2hproject\resources\views/operator/user_index.blade.php ENDPATH**/ ?>